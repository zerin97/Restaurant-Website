# Personal Project

Date Created: 05 03 2022
Last Modification Date: 10 03 2022


## Author(s)

- Full Name: Fariha Zerin Rabita


## Description
 This website is about Mos Eisley Cantina which is a website + pub type place where people can eat and hangout. This website has 4 pages including the home page and the contact page. Other than that, it has separate pages for menu and the information page where it shows the menu with the prices and more detailed information about the place.


## Getting Started 

In order to use the website, first people have to press "okay" when there is a window alert comes saying "welcome". After that from the navigation bar, people can access to all other 3 pages as well. There are also some hyperlinks inside the website where people can use the website more effeciently.


## Citations/Attributions 

1. Normalize.css used from an online source: normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css, Date accessed: 07 March 2022

2. Dummy content used from https://forcemipsum.com Author: Scotty G., URL: https://forcemipsum.com/, Date accessed: 07 March 2022.

3. https://learn.zybooks.com/zybook/DALCSCI1170SampangiWinter2022, the javascript tags and rules, and Date accessed: 07 03 2022.

4. URL: https://www.timeout.com/hong-kong/restaurants/hong-kongs-best-sustainable-restaurants, the image of a restaurant that has been used in the home page, year published: 2018, Date accessed:  07 03 2022

5.  URL: https://stock.adobe.com/ca/search/images?k=japanese+food+collage, the image of some food as a collage that has been used in the home page after the description, year published: 2018, Date accessed:  07 03 2022

6.  URL: https://www.pinterest.ca/pin/91268329922131373/, the image that has been used as the first signature dish of the cantina in the home page, year published: 2016, Date accessed:  07 03 2022

7.  URL: https://www.esquire.com/uk/food-drink/g15926144/best-recipe-instagram-accounts/, the image that has been used as the second signature dish of the cantina in the home page, year published: 2020, Date accessed:  07 03 2022

8. URL: https://bellyfull.net/the-best-appetizers/, the image that has been used in the appetizers section of the menu page, year published: 2020, Date accessed:  07 03 2022

9. URL: https://thehealthsessions.com/shared-meals/, the image that has been used in the platters section of the menu page, year published: 2022, Date accessed:  07 03 2022

10. URL: https://www.123rf.com/photo_13423481_collage-with-different-cocktails.html, the image that has been used in the beverages section of the menu page, year published: 2022, Date accessed:  07 03 2022

11. URL: https://thevegan8.com/12-vegan-desserts-using-sweet-potatoes/, the image that has been used in the desserts section of the menu page, year published: 2020, Date accessed:  07 03 2022

12. URL: https://www.bloomberg.com/news/features/2020-10-20/what-outdoor-dining-may-look-like-in-winter, the image that has been used in the our story section of the about page, year published: 2022, Date accessed:  07 03 2022

13. URL: https://www.istockphoto.com/photos/halifax-nova-scotia, the image that has been used in the location section of the about page, year published: 2018, Date accessed:  07 03 2022

14. URL: https://www.forbes.com/sites/forbescommunicationscouncil/2019/05/10/the-chef-collaborator-lessons-from-cooking-school-on-the-power-of-teamwork/?sh=144252b7ec75, the image that has been used in the contact us section of the contact page, year published: 2016, Date accessed:  07 03 2022

